#version - color place holders - input and retrieving data
#when a new color is inputted == make the loop re run
from tkinter import *
import tkinter as tk
from PIL import ImageTk, Image
import requests, json
import random
import geocoder
import urllib.request
import csv
import os 

#UI PLACEMENT-----------------------------------------------------------------------------------------------------------------#
root = Tk(className="Weather wear")
root.geometry("320x480")


#WEATHER LIST AND TIPS--------------------------------------------------------------------------------------------------------#
#list weather 
weatherDesc = [
    ["light rain", "light intensity shower rain"], 
    ["moderate rain", "shower rain", "rain"], 
    ["heavy intensity rain", "very heavy rain", "extreme rain", "freezing rain", "heavy intensity shower rain", "ragged shower rain"], 
    ["thunderstorm with light rain", "light thunderstorm", "thunderstorm with light drizzle"],
    ["thunderstorm with rain", "thunderstorm", "thunderstorm with drizzle", "thunderstorm"],
    ["thunderstorm with heavy rain", "heavy thunderstorm", "ragged thunderstorm", "thunderstorm with heavy drizzle"],
    ["light intensity drizzle", "light intensity drizzle rain"],
    ["drizzle", "drizzle rain", "shower rain and drizzle", "shower drizzle"],
    ["heavy intensity drizzle", "heavy intensity drizzle rain", "heavy shower rain and drizzle"],
    ["light snow", "Light shower sleet", "Light rain and snow", "Light shower snow"],
    ["Snow", "Sleet", "Rain and snow", "Shower snow", "snow"],
    ["Heavy snow", "Shower sleet", "Heavy shower snow"],
    ["mist", "Smoke", "Haze", "sand/ dust whirls", "fog", "sand", "dust", "volcanic ash", "squalls", "tornado"],
    ["clear sky"],
    ["few clouds: 11-25%", "scattered clouds: 25-50%", "broken clouds: 51-84%", "overcast clouds: 85-100%", "few clouds", "scattered clouds", "broken clouds"]
]
#list desc 
weatherTips = [
    ["Dont forget your umbrella!" , "A hat, hat, hat to protect your head, head, head", "Time to bring out your hat!"],
    ["Dont forget your umbrella!", "Dont forget your raincoat!","Grab your raincoat!"],
    ["Time to bring out the rain boots", "Time to polish your rain boots!","Dont forget your raincoat!","Layer up! it'll be windy!"],
    ["Layer up! a light storm is coming your way", "A hat, hat, hat to protect your head, head, head", "Layer up! prepare for the wind"],
    ["Layer up! a thunderstorm is coming your way", "Laye up your sweater! It's going to be windy", "Dont forget your raincoat!"],
    ["Stay inside or layer up!", "Layer up! its going to be windy", "Maybe forget about that flip flops", "Time to bring our your rain boots!"],
    ["A hat, hat, hat to protect your head, head, head", "Maybe forget about that flip flops, and opt for that boots", "Don't forget your hat!"],
    ["Don't forget your raincoat!", "Time to bring out your raincoat!", "A hat, hat, hat to protect your head, head, head", "Rainboots if you're feeling extra"],
    ["Don't forget your umbrella!", "Time to bring out your raincoat!"],
    ["Time to bring out a thicker coat!", "It's sweater weather!"], 
    ["Time to bring out a thicker coat!", "It's sweater weather!"],
    ["Time to bring out a thicker coat!", "It's sweater weather!"],
    ["Wear your mask Today!", "A hat and glasses to protect you from the dust!", "Dont forget your mask! it will be dusty today"],
    ["Time to bring out your flip flops!", "Time to raid your sunglasses collection!", "Don't forget your sun screen!","Avoid black clothing items to avoid over heating!"],
    ["Maybe rethink that flip flops, its a little windy today", "layer up, its a little cloudy today", "Layer up! its a little cloudy Today", "A sweater Today?"]
]

backImgs = [
    "ui/1lightRain.jpg", "ui/2modRain.jpg", "ui/3heavyRain.jpg", "ui/4lightThunder.jpg", "ui/5modThunder.jpg", "ui/6heavyThunder.jpg", 
    "ui/7lightDrizzle.jpg", "ui/8modDrizzle.jpg", "ui/9heavyDrizzle.jpg", "ui/10lightSnow.jpg", "ui/11modSnow.jpg", "ui/12heavySnow.jpg", 
    "ui/13mist.jpg", "ui/14clearSky.jpg", "ui/15cloudy.jpg"
]

#FINDING GEO LOCATION---------------------------------------------------------------------------------------------------------------#
#Get IP Address
userIP = urllib.request.urlopen('https://ident.me').read().decode('utf8')
#Get Geo Location
g = geocoder.ip(userIP)
userLat= str(g.lat)
userLng= str(g.lng)
print("Latitude: ",userLat)
print("Longitude: ",userLng)

#API CONNECTION---------------------------------------------------------------------------------------------------------------#
BASE_URL = "https://api.openweathermap.org/data/2.5/onecall?"
LATITUDE = userLat
LONGITUDE = userLng
API_KEY = "deeed82620935ce57fe10b65b34c7975"
UNITS = "metric"
EXCLUDE = "minutely,daily,alerts"
# upadting the URL
URL = BASE_URL + "lat=" + LATITUDE + "&lon=" + LONGITUDE + "&appid=" + API_KEY + "&units=" + UNITS + "&exclude=" + EXCLUDE
# HTTP request
response = requests.get(URL)

def convertTuple(tup):
    str =  ''.join(tup)
    return str

def update():
    print("-------------------------------------------------------------------------------------------------------------")
    #updates here
    print("SOFTWARE IS UPDATING...")
    print("-------------------------------------------------------------------------------------------------------------")
    
    #current weather data set configuration------------------------------------------------------#
    tempNow.config(text=tempNowMod)
    print("Current Temperature:", tempNowMod)
    mainNow.config(text=mainNowCollect)
    descNow.config(text=descNowCollect)
    print("Current weather:", mainNowCollect, ",", descNowCollect)

    #weather tips--------------------------------------------------------------------------------#
    counter= -1
    for i in weatherDesc:
        counter += 1
        if mostFreq in i:
            break 
    #print(counter)
    curTipList = weatherTips[counter]
    curTipList = random.choice(curTipList)
    print("Tip of the day: ", curTipList)
    tipLabel.config(text= curTipList)

    #Weather background update for loop----------------------------------------------------------#
    curWeatherBgUpdated = hourlyWeather['description']
    print(curWeatherBgUpdated)
    counterBgUpdated= -1
    for i in weatherDesc:
        counterBgUpdated += 1
        if curWeatherBgUpdated in i:
            break 
    print("COUNTER: ",counterBgUpdated)
    curTipListBgUpdated = backImgs[counterBgUpdated]

    iconTwo = Image.open(curTipListBgUpdated)
    resized = iconTwo.resize((320, 480), Image.ANTIALIAS)
    iconTwoNew = ImageTk.PhotoImage(resized)
    backgroundImg.config(image=iconTwoNew)

    #Updating colors
    f = open("color_archive2.csv", "a", newline="")
    global curColor
    curColor = input("input a color: ")
    writer = csv.writer(f)
    writer.writerow(curColor)
    f.close()

    with open('color_archive2.csv') as csvFile:
        csvReader = csv.reader(csvFile)
        rows = list(csvReader)
        
    margin = 0
    for i in range (-5,0): 
        margin += 40
        if rows[i]:
            print("in row", (i) ,convertTuple(rows[i]))
            colorBox = tk.Frame(primaryFrame, bg=convertTuple(rows[i]), width=25, height=25)
            colorBox.place(x=(215 - margin) , y=10)
            colorBox.pack_propagate(0)

        else:
            print("nothing")

    root.mainloop()

def curWeatherBox():
    mainBG = "white" 
    nowFrame = tk.Frame(root, bg=mainBG , width=135, height=105)
    nowFrame.place(x = 0,y = 165)
    nowFrame.pack_propagate(0)
    
    #current temperature textbox
    tempNowCollect = hourly[0]['temp']
    tempNowCollect = round(tempNowCollect,1)
    print("weather: ", tempNowCollect )
    global tempNowMod
    tempNowMod = tempNowCollect,"\N{DEGREE SIGN}C"
    global tempNow 
    tempNow = Label(nowFrame, text=tempNowMod,
        font = ("Helvetica Neue",36),
        bg='#ffffff', justify=LEFT)
    tempNow.pack(pady=(0,0), padx=(16,0), anchor=W)

    #Main (weather condition) textbox 
    global mainNowCollect
    mainNowCollect = hourlyWeather['main']
    print(hourlyWeather['main'])
    global mainNow
    mainNow = Label(nowFrame, text=mainNowCollect,
                    font = ("Helvetica Neue",18),
                    bg='#ffffff', justify=LEFT)
    mainNow.pack(pady=(0,0),padx=(15,0), anchor=W)

    #Weather description textbox
    global descNowCollect
    descNowCollect = hourlyWeather['description']
    print(descNowCollect)

    global descNow
    descNow = Label(nowFrame, text=descNowCollect,
                    font=("Helvetica Neue", 14),
                    bg='#ffffff', fg='#7E7E7E', justify=LEFT)
    descNow.pack(pady=(0, 0), padx=(15,0), anchor=W)

#to find most frequent weather
def most_frequent(List):
	return max(set(List), key = List.count)

def tipBox():
    tipFrame = tk.Frame(root, width=180, height=75, bg="white")
    tipFrame.place(x = 0,y = 270)
    tipFrame.pack_propagate(0)

    #Averaging the weather to get the best tip
    global data_set
    data_set= []
    for i in range (0,7): #next 9 hours
        hourlyWeather = hourly[i]['weather'] # This is a 0 - length list
        hourlyWeather = hourlyWeather[0] # This is a dictionary
        weaDesc = hourlyWeather['description']
        data_set.append(weaDesc)
    #print("this is the data set:", data_set)
    global mostFreq
    mostFreq = most_frequent(data_set)
    print("MOST FREQUENT WEATHER: ",mostFreq)

    counter= -1
    for i in weatherDesc:
        counter += 1
        if mostFreq in i:
            break 
    #print(counter)
    curTipList = weatherTips[counter]
    curTipList = random.choice(curTipList)
    print("Tip of the day: ", curTipList)

    global tipLabel
    tipLabel = Label(tipFrame, text=curTipList, wraplengt=150, bg="white", justify=LEFT)
    tipLabel.pack(anchor= W, pady=(10,0), padx=(15,0))
    #backImg = Image.open("cloudy.jpg")

def outfitHistory():
    #print("hello")
    #primaryFrame
    global primaryFrame
    primaryFrame = tk.Frame(root, bg='light gray', width=225, height=40)
    primaryFrame.place(x=0, y=350)
    primaryFrame.pack_propagate(0)

    #add an if there are less than 5 rows in csv file
    f = open("color_archive2.csv", "w", newline="")
    writer = csv.writer(f)
    for c in range (5):
        #writer = csv.writer(f)
        c = "gray"
        writer.writerow(c)
        #f.append(c)

    f.close()
    with open('color_archive2.csv') as csvFile:
        csvReader = csv.reader(csvFile)
        rows = list(csvReader)
    
    margin = 0
    for i in range (-5,0): 
        margin += 40
        if rows[i]:
            print("in row", (i) ,convertTuple(rows[i]))
            global colorBox
            colorBox = tk.Frame(primaryFrame, bg=convertTuple(rows[i]), width=25, height=25)
            colorBox.place(x=(215 - margin) , y=10)
            colorBox.pack_propagate(0)

        else:
            print("nothing")
            colorBox = tk.Frame(primaryFrame, bg="gray", width=25, height=25)
            colorBox.place(x=(215 - margin) , y=10)
            colorBox.pack_propagate(0)


    #Text frame
    textFrame = tk.Frame(root, bg='white', width=300, height=55)
    textFrame.place(x=0, y=390)
    textFrame.pack_propagate(0)

    theText="You’ve been wearing a lot of Blue, how about Red today?"
    global tempTwo
    tempTwo = Label(textFrame, text=theText, font=("Helvetica Neue", 14), bg='#ffffff', wraplengt=250, justify=LEFT)
    tempTwo.pack(anchor=W, padx=(15, 0), pady=(10, 0))


if response.status_code == 200:
    data = response.json()
    current = data['current']
    global hourly
    hourly = data['hourly']
    #dataframe = pd.DataFrame.from_dict(data, orient="index")

    #Collect data set
    global hourlyWeather
    hourlyWeather = hourly[0]['weather'] # This is a 0 - length list
    hourlyWeather = hourlyWeather[0] # This is a dictionary


    #Background manipulation-----------------------------------------------------------------------------#
    global curWeatherBg
    curWeatherBg = hourlyWeather['description']
    print(curWeatherBg)
    counterBg= -1
    for i in weatherDesc:
        counterBg += 1
        if curWeatherBg in i:
            break 
    print("COUNTER: ",counterBg)
    curTipListBg = backImgs[counterBg]
    #curTipListBg = random.choice(curTipListBg)
    print("Current weather BACKGROUND: ",curTipListBg)

    #Weather dependent background------------------------------------------------------------------#
    bgFrame = tk.Frame(root, bg="green", width=320, height=480)
    bgFrame.place(x = 0,y = 0)
    bgFrame.pack_propagate(0)
    #Image
    #iconTwo = Image.open(curTipListBg)
    iconTwo = Image.open(curTipListBg)
    resized = iconTwo.resize((320, 480), Image.ANTIALIAS)
    iconTwoNew = ImageTk.PhotoImage(resized)
    global backgroundImg
    backgroundImg = Label(bgFrame, image=iconTwoNew, bg='white')
    backgroundImg.pack(anchor=W, pady=(0, 0), padx=(0, 0))

    #restart button--------------------------------------------------------------------------------#
    restartFrame = tk.Frame(root, bg='#535353', width=30, height=30)
    restartFrame.place(x = 268,y = 22)
    restartFrame.pack_propagate(0)

    restartImg = PhotoImage(file="Group 5.png")
    restartBtn = Button(restartFrame, image=restartImg, command=update) #insert command
    restartBtn.pack()
    
    curWeatherBox()
    tipBox()
    outfitHistory()
    root.mainloop()
else:
    print("Error in the HTTP request")

root.mainloop()